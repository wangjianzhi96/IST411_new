/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testurl;

/**
 *
 * @author jxw5676
 */
public class testObject {
    String time;
    Object CurrencyValue;
    
    private class CurrencyValue {
        String name;
        double value;
    }
}
